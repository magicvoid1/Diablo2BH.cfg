BH Hack v0.1
By McGod

BH is a multi-hack for Diablo II version 1.13c.

Current features:
-Full Maphack

Injection Instructions

   1. Open Diablo II and join a game
   2. Run BH.Injector.exe with Admin Previleges.
   3. Choose which Diablo II you wish to inject into.

User Interface Intructions

Open UI - Control + Click
Drag UI - Click + Drag on Title Bar
Close UI - Right click on Title Bar


Assembla Page
http://www.assembla.com/wiki/show/bh
